// 서버에 API를 요청할 때 사용할 공통적인 url을 정의합니다.
const url = "https://www.seongong.shop";
